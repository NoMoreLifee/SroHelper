edxSilkroadLoader5

You may run edxSilkroadLoader5.exe from any folder as long as edxSilkroadDll5.dll
is also in that directory.

Vista/Win7 users should *Run As Administrator*

Step 1: Configure Silkroad Directories

	Add: Allows you to select a new directory. If the directory already exists
	     you will get an error.

	Refresh: Reloads the current directories. Useful if you updated a Silkroad
	         directory while the tool was running.

	Open: Opens the path to the selected Silkroad directory.

	Remove: Removes the selected Silkroad directory. This action cannot be undone.

Step 2: Select Gateway Server

	Simply choose the Division and Host servers you wish to login with.

Step 3: Configure Patches

	English Patch: Does not work for ISRO or RSRO.

	Multiclient: Patchless multiclient. Does not work with Hackshield.

	Debug Console: Useful for checking patching errors.

	Hook Input: Does not work for KSRO. Allows you to use /min and /exit.

	Nude Patch: kekeke

	Zoom Hack: Infinite zoom out.

	Korean Captcha Hook: Allows you to use KoreanCaptchaGenerator for KSRO's image code.

	NOP Hackshield: Patches out Hackshield loading. Only useful for development tasks.

	Swear Filter: Be careful with this one, people can screenshot you!

	Redirect Gateway Server: Redirects the GatewayServer connection. Useful for devleopment.

	Redirect Agent Server: Redirects all other connections. You have to enable the previous
			       option to use this one. Most people should not need this.

Step 4: Start the Client

	Open Config File: Opens the folder containing the configuration file for edxSilkroadLoader5

	Launch!: Starts the client.


KoreanCaptchaGenerator - 

	You must be using KSRO and have selected "Korean Captcha Hook

	Read the program GUI for instructions!

	See attached images for additional references.