#pragma once

#ifndef CONSOLE_H_
#define CONSOLE_H_

void AddConsole(const char * winTitle);

void RemoveConsole();

#endif
