#pragma once

#ifndef CREATEDIRRECURSIVE_H_
#define CREATEDIRRECURSIVE_H_

//-----------------------------------------------------------------------------

void CreateDirectoryRecursive(const char * path);

//-----------------------------------------------------------------------------

#endif
