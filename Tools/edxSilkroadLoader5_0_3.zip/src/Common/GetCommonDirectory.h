#pragma once

#ifndef GETCOMMONDIR_H_
#define GETCOMMONDIR_H_

//-----------------------------------------------------------------------------

#include <string>

//-----------------------------------------------------------------------------

std::string GetCommonDirectory(const std::string & baseDir);

//-----------------------------------------------------------------------------

#endif
