//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by edxSilkroadLoader5.rc
//
#define IDD_DIALOG1                     101
#define IDC_DIRS                        1001
#define IDC_ADD                         1002
#define IDC_REMOVE                      1003
#define IDC_OPEN                        1004
#define IDC_DIVS                        1005
#define IDC_HOSTS                       1006
#define IDC_COUNTRY                     1007
#define IDC_LANGUAGE                    1008
#define IDC_LOCALE                      1009
#define IDC_VERSION                     1010
#define IDC_PORTS                       1011
#define IDC_PATCH_ENGLISH               1012
#define IDC_PATCH_MULTI                 1013
#define IDC_PATCH_SWEAR                 1014
#define IDC_PATCH_NUDE                  1015
#define IDC_PATCH_KOREA                 1016
#define IDC_PATCH_REDIRECT_GWS          1017
#define IDC_PATCH_REDIRECT_AGS          1018
#define IDC_PATCH_CONSOLE               1019
#define IDC_PATCH_ZOOM                  1020
#define IDC_PATCH_GWS_IP                1021
#define IDC_PATCH_AGS_IP                1022
#define IDC_PATCH_GWS_PORT              1023
#define IDC_PATCH_AGS_PORT              1024
#define IDC_PATCH_HS                    1025
#define IDC_LAUNCH                      1026
#define IDC_REFRESH                     1027
#define IDC_CONFIG                      1028
#define IDC_PATCH_INPUT                 1029
#define IDC_SEED                        1030
#define IDC_AUTO_PARSE                  1031

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
