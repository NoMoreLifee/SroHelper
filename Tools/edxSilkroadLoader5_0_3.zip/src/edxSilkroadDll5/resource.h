//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by edxSilkroadDll5.rc
//
#define IDD_DIALOG1                     102
#define IDC_LOG_AREA                    1001
#define IDC_ALLOW_OPCODE                1002
#define IDC_ALLOW_LIST                  1003
#define IDC_ALLOW_ADD                   1004
#define IDC_ALLOW_REMOVE                1005
#define IDC_ALLOW_RESET                 1006
#define IDC_IGNORE_OPCODE               1007
#define IDC_IGNORE_LIST                 1008
#define IDC_IGNORE_ADD                  1009
#define IDC_IGNORE_REMOVE               1010
#define IDC_IGNORE_RESET                1011
#define IDC_VIEW_CLEAR                  1012
#define IDC_VIEW_SAVE                   1013
#define IDC_FILELOG                     1014
#define IDC_C2S                         1015
#define IDC_S2C                         1016
#define IDC_CLIENT_VIEW                 1017
#define IDC_CON_LIST                    1017
#define IDC_CLIENT_ON                   1018
#define IDC_CLIENT_OFF                  1019
#define IDC_CON_LABEL                   1020
#define IDC_CON_SET_LABEL               1021
#define IDC_CON_ENABLE_LOG              1022
#define IDC_BUTTON1                     1023
#define IDC_REFRESH                     1023
#define IDC_SHOW_DIR                    1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
