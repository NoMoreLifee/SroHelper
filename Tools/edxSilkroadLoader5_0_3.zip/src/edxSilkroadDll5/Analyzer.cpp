#define _CRT_SECURE_NO_DEPRECATE
#include <windows.h>
#include <windowsx.h>
#include <Richedit.h>
#include <shlwapi.h>
#include <shlobj.h>
#include <algorithm>
#include <vector>
#include <fstream>
#include <map>
#include <string>
#include <sstream>
#include "../Common/common.h"
#include "../Common/GetCommonDirectory.h"
#include "resource.h"

std::string base_dir = "edxSilkroadLoader5";

//-----------------------------------------------------------------------------

template <typename t>
t HexStringToInteger(const std::string & str)
{
	t val;
	std::stringstream ss;
	ss << std::hex << str;
	ss >> val;
	return val;
}

//-----------------------------------------------------------------------------

// Main GUI thread
DWORD WINAPI GuiThread(LPVOID lpParam);

// Window procedure for the GUI
INT_PTR CALLBACK DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

// Handle to the gui thread
HANDLE hGuiThread = 0;

bool bDoLogging = true;

// Rich edit controls
HMODULE hRichLib = 0;
HWND hEdit = 0;
HANDLE hFont = 0;

// Log file
FILE * logFile = 0;
int bDoLog = true;

// Filter options
bool bShowC2S = true;
bool bShowS2C = true;
std::vector<DWORD> showOnlyOpcodes;
std::vector<DWORD> filterOpcodes;

HWND hGui = 0;

// Save and load settings
void SaveFilter();
void LoadFilter();

// Ignore opcodes
bool AddIgnoreOpcode(DWORD opcode);
void RemoveIgnoreOpcode(DWORD opcode);
void ClearIgnoreOpcodes();

// Show only opcodes
bool AddAllowOpcode(DWORD opcode);
void RemoveAllowOpcode(DWORD opcode);
void ClearAllowOpcodes();

// Destination
void ShowCtoS(bool show);
void ShowStoC(bool show);
void ToggleCtoS();
void ToggleStoC();

// Get destination
BOOL GetStoC();
BOOL GetCtoS();

// Get lists of opcodes
std::vector<DWORD> GetAllowedOpcodes();
std::vector<DWORD> GetIgnoredOpcodes();

// Appends text to the rich edit view
void AppendText(bool doShow, char *cText);

// Current packet opcode
WORD packet_opcode = 0;
bool packet_show = false;

//
extern HMODULE globalInstance;

//-------------------------------------------------------------------------

void Analyzer_Setup()
{
	hGuiThread = CreateThread(0, 0, GuiThread, 0, 0, 0);
}

//-------------------------------------------------------------------------

void Analyzer_Cleanup()
{
	if(hGuiThread) TerminateThread(hGuiThread, 0);
	if(hFont) DeleteObject(hFont);
	if(hRichLib) FreeLibrary(hRichLib);
	if(logFile) fclose(logFile);
}

//-------------------------------------------------------------------------

void Analyzer_SetOpcode(WORD opcode, bool s2c)
{
	packet_opcode = opcode;

	static char msg[131072] = {0};
	packet_show = false;

	bool b1 = bShowS2C;
	if(!s2c)
		b1 = bShowC2S;
	bool b2 = (showOnlyOpcodes.size() == 0) || (std::find(showOnlyOpcodes.begin(), showOnlyOpcodes.end(), packet_opcode) != showOnlyOpcodes.end());
	bool b3 = (std::find(filterOpcodes.begin(), filterOpcodes.end(), packet_opcode) == filterOpcodes.end());
	bool b4 = std::find(showOnlyOpcodes.begin(), showOnlyOpcodes.end(), packet_opcode) != showOnlyOpcodes.end();
	if((b1 && b2 && b3 && !b4) || b4)
	{
		packet_show = true;
	}

	if(s2c)
		_snprintf(msg, 1023, "[S -> C][%.4X]\r\n", packet_opcode);
	else
		_snprintf(msg, 1023, "[C -> S][%.4X]\r\n", packet_opcode);
	AppendText(packet_show, msg);
}

//-------------------------------------------------------------------------

void Analyzer_StreamData(LPBYTE stream, DWORD count_)
{
	static char msg[131072] = {0};

	int outputsize = count_;
	if(outputsize % 16 != 0) outputsize += (16 - outputsize % 16);
	if(outputsize == 0) outputsize = 16;
	int ctr = 0;
	char ch[17] = {0};
	int x1 = 0;
	for(int x = 0; x < outputsize; ++x)
	{
		BYTE b;
		if(x < (int)count_)
		{
			b = stream[x];
			sprintf(msg + ctr, "%.2X ", b);
			ch[x1] = (isprint(b) && !isspace(b) ? b : '.');
		}
		else
		{
			sprintf(msg + ctr, "   ");
			ch[x1] = '.';
		}
		x1++;
		ctr += 3;
		if((x+1) % 16 == 0)
		{
			x1 = 0;
			sprintf(msg + ctr, "  %s", ch);
			ctr += 18;
			sprintf(msg + ctr, "\r\n");
			ctr += 2;
		}
	}
	//strcat(msg, "\n");
	AppendText(packet_show, msg);
}

//-------------------------------------------------------------------------

void Analyzer_EndPacket()
{
	AppendText(packet_show, "\r\n");
}

//-------------------------------------------------------------------------

// Main GUI thread
DWORD WINAPI GuiThread(LPVOID lpParam)
{
	HWND hwnd = CreateDialog(globalInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DlgProc);
	MSG Msg = {0};
	while(GetMessage(&Msg, NULL, 0, 0) > 0)
	{
		if(!IsDialogMessage(hwnd, &Msg))
		{
			TranslateMessage(&Msg);
			DispatchMessage(&Msg);
		}
	}
	return 0;
}

//-----------------------------------------------------------------------------

// Window procedure for the GUI
INT_PTR CALLBACK DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// Handle the message
	switch(uMsg) 
	{
		// Dialog initialize
		case WM_INITDIALOG:
		{
			// Store the gui window
			hGui = hWnd;

			// Load the dll
			hRichLib = LoadLibraryA("RICHED32.DLL");

			// Create a font
			hFont = CreateFontA(16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "Courier New");

			// Create the log dir and file
			char filename[MAX_PATH + 1] = {0};
			std::string fnstr = GetCommonDirectory(base_dir);
			fnstr += "analyzer";
			CreateDirectoryA(fnstr.c_str(), 0);
			std::string fnstr2 = fnstr;
			fnstr += "\\log\\";
			CreateDirectoryA(fnstr.c_str(), 0);
			fnstr2 += "\\snippets\\";
			CreateDirectoryA(fnstr2.c_str(), 0);
			_snprintf(filename, MAX_PATH, "%s\\%i.txt", fnstr.c_str(), GetTickCount());
			logFile = fopen(filename, "w");
			if(logFile == NULL)
			{
				MessageBoxA(0, "Could not create the logging file.", "Error", MB_ICONERROR);
				ExitProcess(0);
			}

			RECT r = {0};
			ShowWindow(GetDlgItem(hWnd, IDC_LOG_AREA), SW_HIDE);
			GetClientRect(GetDlgItem(hWnd, IDC_LOG_AREA), &r);
			hEdit = CreateWindowA("RichEdit", "", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | WS_VSCROLL | ES_AUTOVSCROLL | ES_NOHIDESEL, 0, 0, r.right, r.bottom, hWnd, NULL, GetModuleHandle(0), NULL);
			if(!hEdit)
			{
				MessageBoxA(hWnd, "Richedit creation failed", "Error", MB_OK | MB_ICONEXCLAMATION);
				return FALSE;
			}

			// Set a fixed width font
			SendMessage(hEdit, WM_SETFONT, (WPARAM)hFont, TRUE);

			// Load the filter
			LoadFilter();

			// Clear out the list boxes
			SendMessage(GetDlgItem(hWnd, IDC_IGNORE_LIST), LB_RESETCONTENT, 0, 0);
			SendMessage(GetDlgItem(hWnd, IDC_ALLOW_LIST), LB_RESETCONTENT, 0, 0);
			SendMessage(GetDlgItem(hWnd, IDC_CLIENT_VIEW), LB_RESETCONTENT, 0, 0);

			// update check boxes with the value from the ini
			Button_SetCheck(GetDlgItem(hWnd, IDC_C2S), GetCtoS());
			Button_SetCheck(GetDlgItem(hWnd, IDC_S2C), GetStoC());

			// Default
			Button_SetCheck(GetDlgItem(hWnd, IDC_CLIENT_ON), BST_CHECKED);

			// Load ignore opcodes
			std::vector<DWORD> filterOpcodes = GetIgnoredOpcodes();
			for(size_t x = 0; x < filterOpcodes.size(); ++x)
			{
				char tmp[256] = {0};
				_snprintf(tmp, 255, "%X", filterOpcodes[x]);
				SendMessage(GetDlgItem(hWnd, IDC_IGNORE_LIST), LB_ADDSTRING, 0, (LPARAM)tmp);
			}

			// Load allow opcodes
			std::vector<DWORD> showOnlyOpcodes = GetAllowedOpcodes();
			for(size_t x = 0; x < showOnlyOpcodes.size(); ++x)
			{
				char tmp[256] = {0};
				_snprintf(tmp, 255, "%X", showOnlyOpcodes[x]);
				SendMessage(GetDlgItem(hWnd, IDC_ALLOW_LIST), LB_ADDSTRING, 0, (LPARAM)tmp);
			}

			// 4 characters max
			SendMessage(GetDlgItem(hWnd, IDC_IGNORE_OPCODE), EM_LIMITTEXT, 4, 0);
			SendMessage(GetDlgItem(hWnd, IDC_ALLOW_OPCODE), EM_LIMITTEXT, 4, 0);

			// Default setting
			Button_SetCheck(GetDlgItem(hWnd, IDC_FILELOG), bDoLog);
		}
		break;

		// Commands
		case WM_COMMAND:
		{
			int button = LOWORD(wParam);
			switch (button)
			{
				// Exit
				case IDCANCEL:
				{
					ShowWindow(hWnd, SW_MINIMIZE);
				} break;

				//-------------------------------------------------------------------------

				// Clear the view
				case IDC_VIEW_CLEAR:
				{
					SetWindowTextA(hEdit, "");
				} break;

				// Save the view
				case IDC_VIEW_SAVE:
				{
					// Get the total characters in the view
					int length = GetWindowTextLength(hEdit);

					// Allocate memory for it
					char * buffer = new char[length + 1];

					// Clear out the buffer
					memset(buffer, 0, length + 1);

					// Get the contents
					GetWindowTextA(hEdit, buffer, length + 1);

					// Filename to save to
					char fn[261] = {0};

					// Build the filename

					std::string fnstr = base_dir;
					fnstr += "\\analyzer\\snippets\\";
					fnstr = GetCommonDirectory(fnstr);
					_snprintf(fn, 260, "%s\\%i.log", fnstr.c_str(), GetTickCount());

					// Create the file
					FILE * outFile = fopen(fn, "w");

					// Make sure it was created
					if(outFile)
					{
						// Save the data and close the file
						fprintf(outFile, "%s", buffer);
						fclose(outFile);
					}
					else
					{
						MessageBoxA(0, "Could not save the snippet.", "Error", MB_ICONERROR);
					}

					// Free the memory
					delete [] buffer;
				} break;

				//-------------------------------------------------------------------------
				// Do not show opcodes

				// Add opcode
				case IDC_IGNORE_ADD:
				{
					char tmp[8] = {0};
					GetWindowTextA(GetDlgItem(hWnd, IDC_IGNORE_OPCODE), tmp, 5);
					int length = GetWindowTextLength(GetDlgItem(hWnd, IDC_IGNORE_OPCODE));

					// Support 3 and 4 byte opcodes, do not think there are 2 or 1 byte opcodes :P
					if(length == 4) if(!isalnum(tmp[0]) || !isalnum(tmp[1]) || !isalnum(tmp[2]) || !isalnum(tmp[3])) break;
					if(length == 3) if(!isalnum(tmp[0]) || !isalnum(tmp[1]) || !isalnum(tmp[2])) break;
					if(length < 3) break;

					if(AddIgnoreOpcode(HexStringToInteger<DWORD>(tmp)))
					{
						SendMessage(GetDlgItem(hWnd, IDC_IGNORE_LIST), LB_ADDSTRING, 0, (LPARAM)tmp);
					}
					SetWindowTextA(GetDlgItem(hWnd, IDC_IGNORE_OPCODE), "");
				} break;

				// Remove opcode
				case IDC_IGNORE_REMOVE:
				{
					LRESULT sel = SendMessage(GetDlgItem(hWnd, IDC_IGNORE_LIST), LB_GETCURSEL, 0, 0);
					if(sel != -1)
					{
						char tmp[1024] = {0};
						SendMessage(GetDlgItem(hWnd, IDC_IGNORE_LIST), LB_GETTEXT, sel, (LPARAM)tmp);
						DWORD opcode = HexStringToInteger<DWORD>(tmp);
						RemoveIgnoreOpcode(opcode);
						SendMessage(GetDlgItem(hWnd, IDC_IGNORE_LIST), LB_DELETESTRING, sel, 0);
					}
				} break;

				// Clear all
				case IDC_IGNORE_RESET:
				{
					if(MessageBoxA(0, "Are you sure you wish to clear the \"Do Not Show Opcodes\" list?", "Confirmation", MB_ICONQUESTION | MB_YESNO | MB_DEFBUTTON2) == IDYES)
					{
						SendMessage(GetDlgItem(hWnd, IDC_IGNORE_LIST), LB_RESETCONTENT, 0, 0);
						ClearIgnoreOpcodes();
					}
				} break;

				//-------------------------------------------------------------------------
				// show only opcodes

				// Add opcode
				case IDC_ALLOW_ADD:
				{
					char tmp[8] = {0};
					GetWindowTextA(GetDlgItem(hWnd, IDC_ALLOW_OPCODE), tmp, 5);
					int length = GetWindowTextLength(GetDlgItem(hWnd, IDC_ALLOW_OPCODE));

					// Support 3 and 4 byte opcodes, do not think there are 2 or 1 byte opcodes :P
					if(length == 4) if(!isalnum(tmp[0]) || !isalnum(tmp[1]) || !isalnum(tmp[2]) || !isalnum(tmp[3])) break;
					if(length == 3) if(!isalnum(tmp[0]) || !isalnum(tmp[1]) || !isalnum(tmp[2])) break;
					if(length < 3) break;

					if(AddAllowOpcode(HexStringToInteger<DWORD>(tmp)))
					{
						SendMessage(GetDlgItem(hWnd, IDC_ALLOW_LIST), LB_ADDSTRING, 0, (LPARAM)tmp);
					}
					SetWindowTextA(GetDlgItem(hWnd, IDC_ALLOW_OPCODE), "");
				} break;

				// Remove opcode
				case IDC_ALLOW_REMOVE:
				{
					LRESULT sel = SendMessage(GetDlgItem(hWnd, IDC_ALLOW_LIST), LB_GETCURSEL, 0, 0);
					if(sel != -1)
					{
						char tmp[1024] = {0};
						SendMessage(GetDlgItem(hWnd, IDC_ALLOW_LIST), LB_GETTEXT, sel, (LPARAM)tmp);
						DWORD opcode = HexStringToInteger<DWORD>(tmp);
						RemoveAllowOpcode(opcode);
						SendMessage(GetDlgItem(hWnd, IDC_ALLOW_LIST), LB_DELETESTRING, sel, 0);
					}
				} break;

				// Clear all
				case IDC_ALLOW_RESET:
				{
					if(MessageBoxA(0, "Are you sure you wish to clear the \"Show Only Opcodes\" list?", "Confirmation", MB_ICONQUESTION | MB_YESNO | MB_DEFBUTTON2) == IDYES)
					{
						SendMessage(GetDlgItem(hWnd, IDC_ALLOW_LIST), LB_RESETCONTENT, 0, 0);
						ClearAllowOpcodes();
					}
				} break;

				//-------------------------------------------------------------------------
				//  General filtering

				// Toggle destinations
				case IDC_S2C:
				{
					ToggleStoC();
				} break;

				// Toggle destinations
				case IDC_C2S:
				{
					ToggleCtoS();
				} break;

				//-------------------------------------------------------------------------

				// Should logging be done
				case IDC_FILELOG:
				{
					bDoLog = Button_GetCheck(GetDlgItem(hWnd, IDC_FILELOG));
				} break;

				//-------------------------------------------------------------------------

				// Enable logging for a selected client
				case IDC_CLIENT_ON:
				case IDC_CLIENT_OFF:
				{
					// Enable logging for this client
					if(button == IDC_CLIENT_ON)
						bDoLogging = true;
					else
						bDoLogging = false;

				} break;

				//-------------------------------------------------------------------------

				case IDC_SHOW_DIR:
				{
					std::string path = GetCommonDirectory("edxSilkroadLoader5");
					ShellExecuteA(hWnd, "open", path.c_str(), NULL, NULL, SW_NORMAL);
				} break;
			}
		} break;

		default:
		{
			// Message not handled
			return FALSE;
		}
	}

	// Message handled
	return TRUE;
}

//-----------------------------------------------------------------------------

// Appends text to the rich edit view
void AppendText(bool doShow, char *cText)
{
	if(logFile && bDoLog) { fprintf(logFile, "%s\n", cText); fflush(logFile); }
	if(doShow && bDoLogging)
	{
		if(!hEdit) return;
		CHARRANGE cr = {-1, -1};
		SendMessage(hEdit, EM_EXSETSEL, 0,(LPARAM)&cr);
		SendMessage(hEdit, EM_REPLACESEL, 0, (LPARAM)cText);
		SendMessage(hEdit, WM_VSCROLL, /*SB_LINEDOWN*/ SB_BOTTOM, (LPARAM)NULL);
	}
}

//-----------------------------------------------------------------------------

// Load the settings
void LoadFilter()
{
	filterOpcodes.clear();
	showOnlyOpcodes.clear();
	DWORD tmp = 0;
	DWORD tmp2 = 0;
	std::string fn = base_dir;
	fn += "\\analyzer\\";
	fn = GetCommonDirectory(fn);
	fn += "filter.ini";
	std::ifstream inFile(fn.c_str());
	if(inFile.is_open() == false)
		return;
	inFile >> bShowC2S;
	inFile >> bShowS2C;
	inFile >> tmp;
	for(size_t x = 0; x < tmp; ++x)
	{
		inFile >> tmp2;
		filterOpcodes.push_back(tmp2);
	}
	inFile >> tmp;
	for(size_t x = 0; x < tmp; ++x)
	{
		inFile >> tmp2;
		showOnlyOpcodes.push_back(tmp2);
	}
	inFile.close();
}

//-----------------------------------------------------------------------------

// Save the settings
void SaveFilter()
{
	std::string fn = base_dir;
	fn += "\\analyzer\\";
	fn = GetCommonDirectory(fn);
	fn += "filter.ini";
	std::ofstream outFile(fn.c_str());
	if(outFile.is_open() == false)
	{
		MessageBoxA(0, "Could not save the analyzer filter.", "Error", MB_ICONERROR);
		return;
	}
	outFile << bShowC2S << std::endl;
	outFile << bShowS2C << std::endl;
	outFile << (int)filterOpcodes.size() << std::endl;
	for(size_t x = 0; x < filterOpcodes.size(); ++x)
	{
		outFile << filterOpcodes[x] << std::endl;
	}
	outFile << (int)(showOnlyOpcodes.size()) << std::endl;
	for(size_t x = 0; x < showOnlyOpcodes.size(); ++x)
	{
		outFile << showOnlyOpcodes[x] << std::endl;
	}
	outFile.close();
}

//-----------------------------------------------------------------------------

// Add an ignore opcode
bool AddIgnoreOpcode(DWORD opcode)
{
	if(std::find(filterOpcodes.begin(), filterOpcodes.end(), opcode) == filterOpcodes.end())
	{
		filterOpcodes.push_back(opcode);
		SaveFilter();
		return true;
	}
	return false;
}

//-----------------------------------------------------------------------------

// Remove an ignore opcode
void RemoveIgnoreOpcode(DWORD opcode)
{
	std::vector<DWORD>::iterator itr = std::find(filterOpcodes.begin(), filterOpcodes.end(), opcode);
	if(itr != filterOpcodes.end())
	{
		filterOpcodes.erase(itr);
		SaveFilter();
	}
}

//-----------------------------------------------------------------------------

// Reset the ignore opcode list
void ClearIgnoreOpcodes()
{
	filterOpcodes.clear();
	SaveFilter();
}

//-----------------------------------------------------------------------------

// Add a show only opcode
bool AddAllowOpcode(DWORD opcode)
{
	if(std::find(showOnlyOpcodes.begin(), showOnlyOpcodes.end(), opcode) == showOnlyOpcodes.end())
	{
		showOnlyOpcodes.push_back(opcode);
		SaveFilter();
		return true;
	}
	return false;
}

//-----------------------------------------------------------------------------

// Remove a show only opcode
void RemoveAllowOpcode(DWORD opcode)
{
	std::vector<DWORD>::iterator itr = std::find(showOnlyOpcodes.begin(), showOnlyOpcodes.end(), opcode);
	if(itr != showOnlyOpcodes.end())
	{
		showOnlyOpcodes.erase(itr);
		SaveFilter();
	}
}

//-----------------------------------------------------------------------------

// Reset the show only opcode list
void ClearAllowOpcodes()
{
	showOnlyOpcodes.clear();
	SaveFilter();
}

//-----------------------------------------------------------------------------

// Destination filtering
void ShowCtoS(bool show)
{
	bShowC2S = show;
	SaveFilter();
}

//-----------------------------------------------------------------------------

// Destination filtering
void ShowStoC(bool show)
{
	bShowS2C = show;
	SaveFilter();
}

//-----------------------------------------------------------------------------

// Toggle client to server packet logging
void ToggleCtoS()
{
	bShowC2S = !bShowC2S;
	SaveFilter();
}

//-----------------------------------------------------------------------------

// Toggle server to client packet logging
void ToggleStoC()
{
	bShowS2C = !bShowS2C;
	SaveFilter();
}

//-----------------------------------------------------------------------------

// Return if the server to client packets are logged
BOOL GetStoC()
{
	return bShowS2C;
}

//-----------------------------------------------------------------------------

// Return if the client to server packets are logged
BOOL GetCtoS()
{
	return bShowC2S;
}

//-----------------------------------------------------------------------------

// Get lists of opcodes
std::vector<DWORD> GetAllowedOpcodes()
{
	return showOnlyOpcodes;
}

//-----------------------------------------------------------------------------

// Get lists of opcodes
std::vector<DWORD> GetIgnoredOpcodes()
{
	return filterOpcodes;
}

//-----------------------------------------------------------------------------
